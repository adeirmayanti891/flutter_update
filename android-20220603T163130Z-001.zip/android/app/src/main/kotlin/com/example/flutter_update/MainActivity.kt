package com.example.flutter_update

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
